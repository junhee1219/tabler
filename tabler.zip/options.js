// A minimal options script for a manifest v3 Chrome extension.
// Add your options logic here.

console.log("Options script loaded");
